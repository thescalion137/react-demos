import {
  ADD_USERS_FAILURE,
  ADD_USERS_REQUEST,
  ADD_USERS_SUCCESS,
  DEELETE_USERS_FAILURE,
  DEELETE_USERS_REQUEST,
  DEELETE_USERS_SUCCESS,
  FETCH_USERS_FAILURE,
  FETCH_USERS_REQUEST,
  FETCH_USERS_SUCCESS,
  UPDATE_USERS_FAILURE,
  UPDATE_USERS_REQUEST,
  UPDATE_USERS_SUCCESS,
} from "../actions/userTypes";

const initialState = {
  loading: false,
  users: [],
  error: "",
};

const userReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_USERS_REQUEST:
      console.log("fetch user request called");
      return {
        ...state,
        loading: true,
      };
    case FETCH_USERS_SUCCESS:
      console.log("fetch user success called");
      return {
        ...state,
        users: action.payload,
        loading: false,
      };
    case FETCH_USERS_FAILURE:
      console.log("fetch user failure called");
      return {
        loading: true,
        users: [],
        error: action.payload,
      };
    //add user reducer
    case ADD_USERS_REQUEST:
      console.log("add user request called");
      return {
        ...state,
        loading: true,
      };
    case ADD_USERS_SUCCESS:
      console.log("add user success called");
      // console.log("add user reducer call : ", action.payload);
      return {
        ...state,
        users: [...state.users, action.payload],
        loading: false,
      };
    case ADD_USERS_FAILURE:
      console.log("add user failure called");
      return {
        loading: true,
        users: [],
        error: action.payload,
      };
    // delete user reducer
    case DEELETE_USERS_REQUEST:
      console.log("delete user request called");
      return {
        ...state,
        loading: true,
      };
    case DEELETE_USERS_SUCCESS:
      console.log("delete user success called");
      return {
        ...state,
        users: state.users.filter((item) => item.id !== action.payload),
        loading: false,
      };
    case DEELETE_USERS_FAILURE:
      console.log("delete user failure called");
      return {
        loading: true,
        users: [],
        error: action.payload.id,
      };

    case UPDATE_USERS_REQUEST:
      console.log("update user request called");

      return {
        ...state,
        loading: true,
      };
    case UPDATE_USERS_SUCCESS:
      // console.log("update user success called", action.payload);

      return {
        ...state,
        users: state.users.map((item) =>
          item.id === action.payload.id ? action.payload : item
        ),
        loading: false,
      };
    case UPDATE_USERS_FAILURE:
      console.log("update user failure called");
      return {
        loading: true,
        users: [],
        error: action.payload,
      };

    default:
      return state;
  }
};

export default userReducer;
