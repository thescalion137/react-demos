import {
  ADD_USERS_FAILURE,
  ADD_USERS_REQUEST,
  ADD_USERS_SUCCESS,
  DEELETE_USERS_FAILURE,
  DEELETE_USERS_REQUEST,
  DEELETE_USERS_SUCCESS,
  FETCH_USERS_FAILURE,
  FETCH_USERS_REQUEST,
  FETCH_USERS_SUCCESS,
  UPDATE_USERS_FAILURE,
  UPDATE_USERS_REQUEST,
  UPDATE_USERS_SUCCESS,
} from "./userTypes";

//Fetch Users
export const fetchUsersRequest = () => {
  return {
    type: FETCH_USERS_REQUEST,
  };
};
export const fetchUsersSuccess = (users) => {
  return {
    type: FETCH_USERS_SUCCESS,
    payload: users,
  };
};
export const fetchUsersFailure = (error) => {
  return {
    type: FETCH_USERS_FAILURE,
    payload: error,
  };
};

//For adding data
export const addUserRequest = () => {
  return {
    type: ADD_USERS_REQUEST,
  };
};
export const addUserSuccess = (user) => {
  return {
    type: ADD_USERS_SUCCESS,
    payload: user,
  };
};
export const addUserFailure = (error) => {
  return {
    type: ADD_USERS_FAILURE,
    payload: error,
  };
};

//For Updating data
export const updateUserRequest = () => {
  return {
    type: UPDATE_USERS_REQUEST,
  };
};
export const updateUserSuccess = (user) => {
  return {
    type: UPDATE_USERS_SUCCESS,
    payload: user,
  };
};
export const updateUserFailure = (error) => {
  return {
    type: UPDATE_USERS_FAILURE,
    payload: error,
  };
};

//For Deleting data
export const deleteUserRequest = () => {
  return {
    type: DEELETE_USERS_REQUEST,
  };
};
export const deleteUserSuccess = (id) => {
  return {
    type: DEELETE_USERS_SUCCESS,
    payload: id,
  };
};
export const deleteUserFailure = (error) => {
  return {
    type: DEELETE_USERS_FAILURE,
    payload: error,
  };
};

//Fetching Data
export const fetchUsers = () => {
  // return (dispatch) => {
  //   dispatch(fetchUsersRequest());
  //   axios
  //     .get("https://fakestoreapi.com/users")
  //     .then((response) => {
  //       const user = response.data;
  //       console.log(user);
  //       dispatch(fetchUsersSuccess(user));
  //     })
  //     .catch((error) => {
  //       const errorMsg = error.message;
  //       dispatch(fetchUsersFailure(errorMsg));
  //     });
  // };
};

//Adding user
export const addUser = (user) => {
  console.log(" add user action call : ", user);
  // return (dispatch) => {
  //   dispatch(addUserRequest());
  //   axios
  //     .post("https://fakestoreapi.com/products", user)
  //     .then((response) => {
  //       const user = response.data;
  //       console.log(response.data);
  //       dispatch(addUserSuccess(user));
  //     })
  //     .catch((error) => {
  //       const errorMsg = error.message;
  //       console.log(errorMsg);
  //       dispatch(addUserFailure());
  //     });
  // };
  return (dispatch) => {
    dispatch(addUserRequest());
    try {
      dispatch(addUserSuccess(user));
    } catch (error) {
      const errorMsg = error.message;
      console.log(errorMsg);
      dispatch(addUserFailure(errorMsg));
    }
  };
};

//Updating Data
export const updateUser = (user) => {
  // return (dispatch) => {
  //   dispatch(updateUserRequest());
  //   axios
  //     .put("https://fakestoreapi.com/products/" + id, user)
  //     .then((response) => {
  //       const user = response.data;
  //       console.log(user);
  //       dispatch(updateUserSuccess(user));
  //     })
  //     .catch((error) => {
  //       const errorMsg = error.message;
  //       console.log(errorMsg);
  //       dispatch(updateUserFailure());
  //     });
  // };
  return (dispatch) => {
    dispatch(updateUserRequest());
    try {
      dispatch(updateUserSuccess(user));
    } catch (error) {
      const errorMsg = error.message;
      console.log(errorMsg);
      dispatch(updateUserFailure(errorMsg));
    }
  };
};

// Deleting data
export const deleteUser = (id) => {
  // return (dispatch) => {
  //   dispatch(deleteProductRequest);
  //   axios.delete("/api/deleteProduct/" + id).then((response) => {
  //     console.log(response.data);
  //     alert(response.data.data);
  //   });
  // };

  return (dispatch) => {
    dispatch(deleteUserRequest());
    try {
      dispatch(deleteUserSuccess(id));
    } catch (error) {
      const errorMsg = error.message;
      console.log(errorMsg);
      dispatch(deleteUserFailure());
    }
  };
};
