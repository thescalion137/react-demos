import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import { Provider } from "react-redux";
import store from "./redux/store";
import AddUser from "./components/AddUser";
import Home from "./components/Home";
import ViewUser from "./components/ViewUser";
import FileUpload from "./components/FileUpload";
import RegisterUser from "./components/RegisterUser";
import UpdateUser from "./components/UpdateUser";
import TableTest from "./components/TableTest";

function App() {
  return (
    <Provider store={store}>
      <div className="App">
        <Router>
          <Routes>
            <Route path="/" element={<TableTest />} />
            <Route path="/home" element={<Home />} />
            <Route path="/registerUser" element={<RegisterUser />} />
            <Route path="/table" element={<TableTest />} />
            <Route path="/home/updateUser" element={<UpdateUser />} />
            <Route path="/table/updateUser" element={<UpdateUser />} />
            <Route path="/addUser" element={<AddUser />} />
            <Route path="/viewUser" element={<ViewUser />} />
            <Route path="/fileUplaod" element={<FileUpload />} />
          </Routes>
        </Router>
      </div>
    </Provider>
  );
}

export default App;
