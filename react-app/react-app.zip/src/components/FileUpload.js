import React, { useState } from "react";
import { Form, Button, Image } from "react-bootstrap";

const FileUpload = () => {
  const [image, setImage] = useState("");
  return (
    <div>
      <h2>File Upload</h2>

      <Form>
        <Form.Group controlId="formFile" className="mb-3">
          <Form.Label>Default file input example</Form.Label>
          <Form.Control
            type="file"
            onChange={(e) => {
              console.log(URL.createObjectURL(e.target.files[0]));
              setImage(URL.createObjectURL(e.target.files[0]));
            }}
          />
        </Form.Group>
        <Button variant="primary" type="submit">
          Submit
        </Button>
        <Image src={image} />
      </Form>
    </div>
  );
};

export default FileUpload;
