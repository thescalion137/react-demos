import React, { useState } from "react";
import { TableBody, TableCell, TablePagination } from "@mui/material";
import { TableHead } from "@mui/material";
import { TableRow } from "@mui/material";
import { TableSortLabel } from "@mui/material";
import { TableContainer } from "@mui/material";
import { Table } from "@mui/material";

import Header from "./Header";

const TableTest = () => {
  const [orderDirection, setOrderDirection] = useState("asc");
  const [valueToOrderBy, setValueToOrderBy] = useState("username");
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(1);

  const rowInformation = [
    { name: "bob johnson", age: 32 },
    { name: "jay johnson", age: 12 },
  ];

  function descendingComparator(a, b, orderBy) {
    console.log("a : ", a);
    console.log("b : ", b);
    console.log("order by : ", orderBy);
    if (b[orderBy] < a[orderBy]) {
      return -1;
    }
    if (b[orderBy] > a[orderBy]) {
      return 1;
    }
    return 0;
  }

  function getComparator(order, orderBy) {
    return order === "desc"
      ? (a, b) => descendingComparator(a, b, orderBy)
      : (a, b) => -descendingComparator(a, b, orderBy);
  }

  const sortedRowInformation = (rowArray, comparator) => {
    console.log("row information : ", rowArray);
    console.log("comparator : ", comparator);
    const stabilizedRowArray = rowArray.map((el, index) => [el, index]);
    stabilizedRowArray.sort((a, b) => {
      const order = comparator(a[0], b[0]);
      if (order !== 0) return order;
      return a[1] - b[1];
    });
    return stabilizedRowArray.map((el) => el[0]);
  };

  const handleRequestSort = (event, property) => {
    const isAscending = valueToOrderBy === property && orderDirection === "asc";
    setValueToOrderBy(property);
    setOrderDirection(isAscending ? "desc" : "asc");
  };

  const createSortHandler = (property) => (event) => {
    handleRequestSort(event, property);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangesRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value), 10);
    setPage(0);
  };

  return (
    <div>
      <Header />
      <h3>Table</h3>

      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              {/* <TableCell key="image">
                <TableSortLabel
                  active={"image" === "image"}
                  direction="asc"
                  //   onClick={createSortHandler("name")}
                >
                  Image
                </TableSortLabel>
              </TableCell> */}
              <TableCell key="username">
                <TableSortLabel
                  active={valueToOrderBy === "name"}
                  direction={valueToOrderBy === "name" ? orderDirection : "asc"}
                  onClick={createSortHandler("name")}
                >
                  Username
                </TableSortLabel>
              </TableCell>
              <TableCell key="email">
                <TableSortLabel
                  active={valueToOrderBy === "email"}
                  direction={
                    valueToOrderBy === "email" ? orderDirection : "asc"
                  }
                  onClick={createSortHandler("email")}
                >
                  Email
                </TableSortLabel>
              </TableCell>
              {/* <TableCell key="gender">
                <TableSortLabel active={"gender" === "gender"}>
                  Gender
                </TableSortLabel>
              </TableCell>
              <TableCell key="dob">
                <TableSortLabel active={"dob" === "dob"}>
                  Birth Date
                </TableSortLabel>
              </TableCell>
              <TableCell key="city">
                <TableSortLabel active={"city" === "city"}>City</TableSortLabel>
              </TableCell>
              <TableCell key="state">
                <TableSortLabel active={"state" === "state"}>
                  State
                </TableSortLabel>
              </TableCell>
              <TableCell key="langauges">
                <TableSortLabel active={"langauges" === "langauges"}>
                  Langauges
                </TableSortLabel>
              </TableCell>
              <TableCell key="action">
                <TableSortLabel>Actions</TableSortLabel>
              </TableCell> */}
            </TableRow>
          </TableHead>

          <TableBody>
            {sortedRowInformation(
              rowInformation,
              getComparator(orderDirection, valueToOrderBy)
            )
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((person, index) => (
                <TableRow key={index}>
                  <TableCell>{person.name}</TableCell>
                  <TableCell>{person.age}</TableCell>
                </TableRow>
              ))}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[1, 2]}
        component="div"
        count={rowInformation.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangesRowsPerPage}
      />
    </div>
  );
};

export default TableTest;
