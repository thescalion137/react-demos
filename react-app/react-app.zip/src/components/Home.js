import React, { useState } from "react";
import Header from "./Header";
import { Provider, useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import { deleteUser } from "../redux/actions/userAction";
import { useNavigate } from "react-router-dom";
import { Form, Table, Image, Button } from "react-bootstrap";

import { FaEdit, FaPlusCircle } from "react-icons/fa";
import { MdDelete } from "react-icons/md";
import { TablePagination } from "@mui/material";

const Home = () => {
  const userData = useSelector((state) => state.user);
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const dispatch = useDispatch();

  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(2);

  const handleDelete = (id) => {
    console.log("delete clicked", id);
    dispatch(deleteUser(id));
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangesRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value), 10);
    setPage(0);
  };

  return (
    <div className="">
      <Header />
      {/* {console.log(userData)} */}
      <div className="container py-5 h-100 max-width: 100% ">
        <div className="row d-flex justify-content-center align-items-center h-100">
          <div>
            <div className="card rounded-3">
              <div className="card-body p-4 p-md-5">
                <h3 className="mb-4 pb-2 pb-md-0 mb-md-5 px-md-2">
                  Users Info
                </h3>

                <div
                  style={{
                    display: "flex",
                    flexDirection: "row-reverse",
                    marginBottom: 10,
                  }}
                >
                  <Button onClick={() => navigate("/registerUser")}>
                    <FaPlusCircle size={15} />
                    &nbsp; Add New User
                  </Button>
                  <Form.Control
                    style={{ width: "25%", marginRight: 20 }}
                    className="g-2"
                    placeholder="Search..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>
                <Table striped bordered hover responsive>
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Image</th>
                      <th>Username</th>
                      <th>Email</th>
                      <th>Gender</th>
                      <th>Birth Date</th>
                      <th>City</th>
                      <th>State</th>
                      <th>Langauges</th>
                      <th>Actions</th>
                    </tr>
                  </thead>

                  {console.log("userdata loading   : ", userData.loading)}

                  {userData.users.length === 0 ? (
                    <tbody
                      style={{ textAlign: "center", verticalAlign: "middle" }}
                    >
                      <tr>
                        <td colSpan={10}>No Data found</td>
                      </tr>
                    </tbody>
                  ) : (
                    <tbody
                      style={{ textAlign: "center", verticalAlign: "middle" }}
                    >
                      {userData &&
                        userData.users &&
                        userData.users
                          .filter((val) => {
                            if (search === "") {
                              return val;
                            } else if (val.username.includes(search)) {
                              return val;
                            }
                          })
                          .slice(
                            page * rowsPerPage,
                            page * rowsPerPage + rowsPerPage
                          )
                          .map((usr, index) => (
                            <tr key={index}>
                              <td>{usr.id}</td>
                              <td>
                                <div className="form-outline mb-4 text-center ">
                                  <img
                                    src={usr.image}
                                    className="img-thumbnail rounded-circle z-depth-1-half avatar-pic"
                                    height={150}
                                    width={150}
                                  ></img>
                                </div>
                              </td>
                              <td className="alignTextBottom">
                                {usr.username}
                              </td>
                              <td>{usr.email}</td>
                              <td>{usr.gender}</td>
                              <td>{usr.dob}</td>
                              <td>{usr.city}</td>
                              <td>{usr.state}</td>
                              <td>
                                {usr.language.length == 0
                                  ? ""
                                  : usr.language + ","}
                              </td>

                              <td>
                                <FaEdit
                                  onClick={() =>
                                    navigate("updateUser", {
                                      state: { id: usr.id, user: usr },
                                    })
                                  }
                                />
                                &nbsp;
                                <MdDelete
                                  onClick={() => handleDelete(usr.id)}
                                />
                              </td>
                            </tr>
                          ))}
                    </tbody>
                  )}
                </Table>
                <TablePagination
                  rowsPerPageOptions={[2, 3, 4, 5]}
                  component="div"
                  count={userData.users.length}
                  rowsPerPage={rowsPerPage}
                  page={page}
                  onPageChange={handleChangePage}
                  onRowsPerPageChange={handleChangesRowsPerPage}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
