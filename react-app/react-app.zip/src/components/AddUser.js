import React, { useState, useEffect } from "react";
import Header from "./Header";
import { Form, Button, Row, Col } from "react-bootstrap";
import { useDispatch } from "react-redux";
import { addUser } from "../redux/actions/userAction";
import * as Yup from "yup";
import { useFormik } from "formik";
let id = 0;
const AddUser = () => {
  const dispatch = useDispatch();
  // const [username, setUsername] = useState();
  // const [email, setEmail] = useState();
  // const [password, setPassword] = useState();
  // const [city, setCity] = useState();
  // const [state, setState] = useState();
  // const [zip, setZip] = useState();
  // const [gender, setGender] = useState();
  const [image, setImage] = useState();
  const [languages, setLanguages] = useState({
    hindi: false,
    gujarati: false,
    english: false,
  });
  var keys = Object.keys(languages);
  var filtered = keys.filter(function (key) {
    return languages[key];
  });

  const formik = useFormik({
    initialValues: {
      username: "",
      email: "",
      password: "",
      city: "",
      state: "",
      zip: "",
      gender: "",
      image: "",
      languages: [],
    },
    onSubmit: (values) => {
      const user = {
        id: (id += 1),
        username: values.username,
        email: values.email,
        password: values.password,
        language: filtered,
        city: values.city,
        state: values.state,
        zip: values.zip,
        gender: values.gender,
        image: image,
      };
      dispatch(addUser(user));
    },
  });

  // useEffect(() => {
  //   console.log(languages);
  // }, [languages]);

  const handleCheckLangauge = (e) => {
    setLanguages({ ...languages, [e.target.name]: e.target.checked });
  };

  // const handleSubmit = (e) => {
  //   const user = {
  //     id: (id += 1),
  //     username: username,
  //     email: email,
  //     password: password,
  //     language: filtered,
  //     city: city,
  //     state: state,
  //     zip: zip,
  //     gender: gender,
  //     image: image,
  //   };
  //   e.preventDefault();
  //   dispatch(addUser(user));
  // };

  return (
    <div>
      <Header />
      <h1>Add User</h1>
      <div className="container py-5 h-100">
        <div className="row d-flex justify-content-center align-items-center h-100">
          <div className="col-lg-8 col-xl-6">
            <div className="card rounded-3">
              <div className="card-body p-4 p-md-5">
                <h3 className="mb-4 pb-2 pb-md-0 mb-md-5 px-md-2">
                  Registration Info
                </h3>
                <Form onSubmit={formik.handleSubmit}>
                  <Form.Group className="mb-3">
                    <Form.Label>Username</Form.Label>
                    <Form.Control
                      placeholder="username"
                      name="username"
                      value={formik.values.username}
                      onChange={formik.handleChange}
                    />
                    <Row className="mb-3">
                      <Form.Group as={Col}>
                        <Form.Label>Email</Form.Label>
                        <Form.Control
                          type="email"
                          name="email"
                          placeholder="Enter email"
                          value={formik.values.email}
                          onChange={formik.handleChange}
                        />
                      </Form.Group>

                      <Form.Group as={Col}>
                        <Form.Label>Password</Form.Label>
                        <Form.Control
                          type="password"
                          name="password"
                          placeholder="Password"
                          value={formik.values.password}
                          onChange={formik.handleChange}
                        />
                      </Form.Group>
                    </Row>
                  </Form.Group>

                  <Row className="mb-3">
                    <Form.Group as={Col}>
                      <Form.Label>City</Form.Label>
                      <Form.Control
                        type="text"
                        name="city"
                        placeholder="city"
                        value={formik.values.city}
                        onChange={formik.handleChange}
                      />
                    </Form.Group>

                    <Form.Group as={Col}>
                      <Form.Label>State</Form.Label>
                      <Form.Select
                        defaultValue="Choose..."
                        name="state"
                        value={formik.values.state}
                        onChange={formik.handleChange}
                      >
                        <option>Choose...</option>
                        <option>Gujrat</option>
                        <option>Maharashtra</option>
                        <option>Punjab</option>
                      </Form.Select>
                    </Form.Group>

                    <Form.Group as={Col}>
                      <Form.Label>Zip</Form.Label>
                      <Form.Control
                        name="zip"
                        placeholder="Zip"
                        value={formik.values.zip}
                        onChange={formik.handleChange}
                      />
                    </Form.Group>
                  </Row>
                  <Row className="mb-3">
                    <Form.Group
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                      }}
                    >
                      <Form.Label>Langauges : </Form.Label>
                      <Form.Check
                        type="checkbox"
                        label="English"
                        name="english"
                        onChange={handleCheckLangauge}
                      />
                      <Form.Check
                        type="checkbox"
                        label="Hindi"
                        name="hindi"
                        onChange={handleCheckLangauge}
                      />
                      <Form.Check
                        type="checkbox"
                        label="Gujrati"
                        name="gujarati"
                        onChange={handleCheckLangauge}
                      />
                    </Form.Group>
                  </Row>
                  <Row className="mb-3">
                    <Form.Group as={Col}>
                      <Form.Label>Gender : </Form.Label>
                    </Form.Group>
                    <Form.Group as={Col}>
                      <Form.Check
                        type="radio"
                        label="Male"
                        value="Male"
                        name="gender"
                        onChange={formik.handleChange}
                      />
                    </Form.Group>
                    <Form.Group as={Col}>
                      <Form.Check
                        type="radio"
                        label="Female"
                        value="female"
                        name="gender"
                        onChange={formik.handleChange}
                      />
                    </Form.Group>
                  </Row>

                  <Form.Group controlId="formFile" className="mb-3">
                    <Form.Label>Upload Image :</Form.Label>
                    <Form.Control
                      type="file"
                      onChange={(e) => {
                        setImage(URL.createObjectURL(e.target.files[0]));
                      }}
                    />
                  </Form.Group>

                  <Button
                    variant="primary"
                    type="submit"
                    // onClick={handleSubmit}
                  >
                    Submit
                  </Button>
                </Form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddUser;
