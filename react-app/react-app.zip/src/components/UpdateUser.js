import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";
import { useDispatch } from "react-redux";
import { updateUser } from "../redux/actions/userAction";
import * as Yup from "yup";
import { useFormik } from "formik";

const UpdateUser = () => {
  const { state } = useLocation();
  const updateId = state;
  const userData = state;
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [image, setImage] = useState(userData.user.image);
  const [languages, setLanguages] = useState({
    Hindi: userData.user.language.includes("Hindi"),
    Gujarati: userData.user.language.includes("Gujarati"),
    English: userData.user.language.includes("English"),
  });
  var keys = Object.keys(languages);
  var filtered = keys.filter(function (key) {
    return languages[key];
  });

  // useEffect(() => {
  //   console.log(languages);
  // }, [languages]);

  const handleCheckLangauge = (e) => {
    setLanguages({ ...languages, [e.target.name]: e.target.checked });
  };

  const formik = useFormik({
    initialValues: {
      id: userData.user.id,
      username: userData.user.username,
      email: userData.user.email,
      password: userData.user.password,
      cPassword: userData.user.cPassword,
      dob: userData.user.dob,
      address: userData.user.address,
      city: userData.user.city,
      state: userData.user.state,
      gender: userData.user.gender,
      language: [],
      image: userData.user.image,
    },
    validationSchema: Yup.object({
      username: Yup.string()
        .min(3, "* Username is to short")
        .required("* Please enter Username"),
      email: Yup.string()
        .email("* Invalid email address")
        .required("* Please Enter Email"),
      password: Yup.string()
        .min(6, "* Your Password is to short")
        .required("* Please enter your password"),
      cPassword: Yup.string()
        .required(" * Please enter your password")
        .oneOf([Yup.ref("password")], "* Your passwords do not match."),
      dob: Yup.date().required(" * Please enter your Birth Date"),
      address: Yup.string().required(" * Please enter your Address"),
      state: Yup.string().required(" * Please enter Select ypur State"),
      city: Yup.string().required(" * Please select your City"),
      gender: Yup.string().required(" * Please select Gender"),
    }),
    onSubmit: (values) => {
      const user = {
        id: values.id,
        username: values.username,
        email: values.email,
        password: values.password,
        cPassword: values.cPassword,
        dob: values.dob,
        address: values.address,
        language: filtered,
        city: values.city,
        state: values.state,
        gender: values.gender,
        image: image,
      };
      dispatch(updateUser(user));
      navigate("/table");
      console.log(user);
    },
  });

  return (
    <div>
      {console.log("userdata : ", userData.user.password)}
      <section className="h-100 bg-dark">
        <div className="container py-5 h-100">
          <div className="row d-flex justify-content-center align-items-center h-100">
            <div className="col">
              <div className="card card-registration my-4">
                <div className="row g-0">
                  <div className="col-xl-6 d-none d-xl-block">
                    <img
                      src="https://images.unsplash.com/photo-1595123336219-5eedd543bc4a?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80"
                      alt="Sample photo"
                      className="img-fluid"
                      style={{
                        borderTopLeftRadius: ".25rem",
                        borderBottomLeftRadius: ".25rem",
                      }}
                    />
                  </div>
                  <div className="col-xl-6">
                    <form onSubmit={formik.handleSubmit}>
                      <div className="card-body p-md-5 text-black">
                        <h3 className="mb-5 text-uppercase">Update User</h3>

                        <div className="row">
                          <div className="col-md-6 mb-4">
                            <div className="form-floating mb-3">
                              <input
                                type="text"
                                className="form-control form-control-lg"
                                style={{ borderRadius: "8px" }}
                                placeholder="Username"
                                name="username"
                                value={formik.values.username}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                              />
                              {formik.touched.username &&
                              formik.errors.username ? (
                                <div style={{ color: "red" }}>
                                  {formik.errors.username}
                                </div>
                              ) : null}
                              <label className="form-label">Username </label>
                            </div>
                          </div>

                          <div className="col-md-6 mb-4">
                            <div className="form-floating mb-3">
                              <input
                                type="text"
                                className="form-control form-control-lg"
                                style={{ borderRadius: "8px" }}
                                placeholder="Email"
                                name="email"
                                value={formik.values.email}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                              />
                              {formik.touched.email && formik.errors.email ? (
                                <div style={{ color: "red" }}>
                                  {formik.errors.email}
                                </div>
                              ) : null}
                              <label className="form-label">Email </label>
                            </div>
                          </div>
                        </div>

                        <div className="row">
                          <div className="col-md-6 mb-4">
                            <div className="form-floating mb-3">
                              <input
                                type="text"
                                className="form-control form-control-lg"
                                style={{ borderRadius: "8px" }}
                                placeholder="Password"
                                name="password"
                                value={formik.values.password}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                              />
                              {formik.touched.password &&
                              formik.errors.password ? (
                                <div style={{ color: "red" }}>
                                  {formik.errors.password}
                                </div>
                              ) : null}
                              <label className="form-label">Password </label>
                            </div>
                          </div>
                          <div className="col-md-6 mb-4">
                            <div className="form-floating mb-3">
                              <input
                                type="text"
                                className="form-control form-control-lg"
                                style={{ borderRadius: "8px" }}
                                placeholder="Confirm Password"
                                name="cPassword"
                                value={formik.values.cPassword}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                              />
                              {formik.touched.cPassword &&
                              formik.errors.cPassword ? (
                                <div style={{ color: "red" }}>
                                  {formik.errors.cPassword}
                                </div>
                              ) : null}
                              <label className="form-label">
                                Confirm Password
                              </label>
                            </div>
                          </div>
                        </div>

                        <div className="row">
                          <div className="col-md-6 mb-4">
                            <div className="form-floating mb-3">
                              <input
                                type="date"
                                className="form-control form-control-lg"
                                style={{ borderRadius: "8px" }}
                                placeholder="Date of Birth"
                                name="dob"
                                value={formik.values.dob}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                              />
                              {formik.touched.dob && formik.errors.dob ? (
                                <div style={{ color: "red" }}>
                                  {formik.errors.dob}
                                </div>
                              ) : null}
                              <label className="form-label">
                                Date of Birth
                              </label>
                            </div>
                          </div>
                          <div className="col-md-6 mb-4">
                            <div className="form-floating mb-3">
                              <input
                                type="text"
                                className="form-control form-control-lg"
                                style={{ borderRadius: "8px" }}
                                placeholder="Address"
                                name="address"
                                value={formik.values.address}
                                onChange={formik.handleChange}
                                onBlur={formik.handleBlur}
                              />
                              {formik.touched.address &&
                              formik.errors.address ? (
                                <div style={{ color: "red" }}>
                                  {formik.errors.address}
                                </div>
                              ) : null}
                              <label className="form-label">Address</label>
                            </div>
                          </div>
                        </div>

                        <div className="row ">
                          <div className="col-md-6 mb-4">
                            <div className="form-floating">
                              <select
                                className="form-select"
                                style={{ borderRadius: "8px" }}
                                aria-label="Floating label select example"
                                name="state"
                                value={formik.values.state}
                                onChange={formik.handleChange}
                              >
                                <option style={{ borderRadius: "8px" }}>
                                  Open this select menu
                                </option>
                                <option value="Gujrat">Gujrat</option>
                                <option value="Maharashtra">Maharashtra</option>
                                <option value="punjab">Punjab</option>
                              </select>
                              {formik.touched.state && formik.errors.state ? (
                                <div style={{ color: "red" }}>
                                  {formik.errors.state}
                                </div>
                              ) : null}
                              <label>State</label>
                            </div>
                          </div>
                          <div className="col-md mb-4">
                            <div className="form-floating">
                              <select
                                className="form-select"
                                style={{ borderRadius: "8px" }}
                                aria-label="Floating label select example"
                                name="city"
                                value={formik.values.city}
                                onChange={formik.handleChange}
                              >
                                <option>Open this select menu</option>
                                <option value="Surat">Surat</option>
                                <option value="Bhavnagar">Bhavnagar</option>
                                <option value="Amreli">Amreli</option>
                              </select>
                              {formik.touched.city && formik.errors.city ? (
                                <div style={{ color: "red" }}>
                                  {formik.errors.city}
                                </div>
                              ) : null}
                              <label>City</label>
                            </div>
                          </div>
                        </div>

                        <div className="row ">
                          <div className="col-md-6">
                            <div className="d-md-flex justify-content-start align-items-center mb-2 py-2">
                              <h6 className="mb-0 me-4">Gender:</h6>

                              <div className="form-check form-check-inline mb-0 me-4">
                                <input
                                  className="form-check-input"
                                  type="radio"
                                  name="gender"
                                  value="Female"
                                  checked={formik.values.gender === "Female"}
                                  onChange={formik.handleChange}
                                />
                                <label className="form-check-label">
                                  Female
                                </label>
                              </div>

                              <div className="form-check form-check-inline mb-0 me-4">
                                <input
                                  className="form-check-input"
                                  type="radio"
                                  name="gender"
                                  value="Male"
                                  checked={formik.values.gender == "Male"}
                                  onChange={formik.handleChange}
                                />
                                <label className="form-check-label">Male</label>
                              </div>

                              <div className="form-check form-check-inline mb-0">
                                <input
                                  className="form-check-input"
                                  type="radio"
                                  name="gender"
                                  value="Other"
                                  checked={formik.values.gender === "Other"}
                                  onChange={formik.handleChange}
                                />
                                <label className="form-check-label">
                                  Other
                                </label>
                              </div>
                            </div>
                            {formik.touched.gender && formik.errors.gender ? (
                              <div style={{ color: "red" }}>
                                {formik.errors.gender}
                              </div>
                            ) : null}
                          </div>
                          <div className="col-md">
                            <div className="d-md-flex justify-content-start align-items-center mb-4 py-2">
                              <h6 className="mb-0 me-4">Langauges:</h6>

                              <div className="form-check form-check-inline mb-0 me-4">
                                <input
                                  className="form-check-input"
                                  type="checkbox"
                                  name="English"
                                  defaultChecked={userData.user.language.includes(
                                    "English"
                                  )}
                                  onChange={handleCheckLangauge}
                                />
                                <label className="form-check-label">
                                  English
                                </label>
                              </div>

                              <div className="form-check form-check-inline mb-0 me-4">
                                <input
                                  className="form-check-input"
                                  type="checkbox"
                                  name="Hindi"
                                  defaultChecked={userData.user.language.includes(
                                    "Hindi"
                                  )}
                                  onChange={handleCheckLangauge}
                                />
                                <label className="form-check-label">
                                  Hindi
                                </label>
                              </div>

                              <div className="form-check form-check-inline mb-0 me-4">
                                <input
                                  className="form-check-input"
                                  type="checkbox"
                                  name="Gujarati"
                                  defaultChecked={userData.user.language.includes(
                                    "Gujarati"
                                  )}
                                  onChange={handleCheckLangauge}
                                />
                                <label className="form-check-label">
                                  Gujarati
                                </label>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="form-outline mb-4">
                          <h6 className="mb-2 me-4">Profile Picture:</h6>
                          <input
                            type="file"
                            style={{ borderRadius: "8px" }}
                            className="form-control form-control-lg"
                            name="image"
                            onChange={(e) => {
                              setImage(URL.createObjectURL(e.target.files[0]));
                            }}
                          />
                        </div>
                        <div className="form-outline mb-4 text-center ">
                          <img
                            src={image}
                            alt="..."
                            className="img-thumbnail rounded-circle z-depth-1-half avatar-pic"
                            height={200}
                            width={200}
                          ></img>
                        </div>

                        <div className="d-flex justify-content-end pt-3">
                          {/* <button
                            type="button"
                            style={{ borderRadius: "25px" }}
                            className="btn btn-light btn-lg"
                          >
                            Reset all
                          </button> */}
                          <button
                            type="submit"
                            style={{ borderRadius: "25px" }}
                            className="btn btn-warning btn-lg ms-2"
                          >
                            Update User
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default UpdateUser;
