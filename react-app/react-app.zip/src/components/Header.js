import React from "react";
import { Navbar, Nav, Container } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
const Header = () => {
  let navigate = useNavigate();
  return (
    <div>
      <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
        <Container>
          <Navbar.Brand href="#home">React-Redux</Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="me-auto">
              <Nav.Link onClick={() => navigate("/home")}>Home</Nav.Link>
              {/* <Nav.Link onClick={() => navigate("/addUser")}>Add User</Nav.Link> */}
              <Nav.Link onClick={() => navigate("/table")}>
                Filter Table
              </Nav.Link>
              <Nav.Link onClick={() => navigate("/registerUser")}>
                Register User
              </Nav.Link>
              {/* <Nav.Link onClick={() => navigate("/viewUser")}>
                View User
              </Nav.Link> */}
              {/* <Nav.Link onClick={() => navigate("/home")}>file Upload</Nav.Link> */}
            </Nav>
            <Nav>
              {/* <Nav.Link href="#deets">More deets</Nav.Link>
              <Nav.Link eventKey={2} href="#memes">
                Dank memes
              </Nav.Link> */}
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </div>
  );
};

export default Header;
