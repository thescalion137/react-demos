import React, { useState } from "react";
import { TableBody, TableCell, TablePagination } from "@mui/material";
import { TableHead } from "@mui/material";
import { TableRow } from "@mui/material";
import { TableSortLabel } from "@mui/material";
import { TableContainer } from "@mui/material";
// import { Table } from "@mui/material";
import { Provider, useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import { deleteUser } from "../redux/actions/userAction";
import { useNavigate } from "react-router-dom";
import { Form, Table, Image, Button, Modal } from "react-bootstrap";

import { FaEdit, FaPlusCircle } from "react-icons/fa";
import { MdDelete, MdVisibility } from "react-icons/md";
// import { TablePagination } from "@mui/material";
import Header from "./Header";

const TableTest = () => {
  const userData = useSelector((state) => state.user);
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const dispatch = useDispatch();

  //Pagination
  const [orderDirection, setOrderDirection] = useState("asc");
  const [valueToOrderBy, setValueToOrderBy] = useState("username");
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(2);
  //for model
  const [deleteId, setDeleteId] = useState(0);
  const [showDelete, setShowDelete] = useState(false);
  const handleCloseDelete = () => {
    setShowDelete(false);
  };
  const handleShowDelete = (id) => {
    setDeleteId(id);
    setShowDelete(true);
  };
  const handleDelete = (id) => {
    dispatch(deleteUser(id));
    setShowDelete(false);
  };
  //Pagination & Filtering
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };
  const handleChangesRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value), 10);
    setPage(0);
  };
  function descendingComparator(a, b, orderBy) {
    // console.log("a : ", a);
    // console.log("b : ", b);
    // console.log("order by : ", orderBy);
    if (b[orderBy] < a[orderBy]) {
      return -1;
    }
    if (b[orderBy] > a[orderBy]) {
      return 1;
    }
    return 0;
  }
  function getComparator(order, orderBy) {
    return order === "desc"
      ? (a, b) => descendingComparator(a, b, orderBy)
      : (a, b) => -descendingComparator(a, b, orderBy);
  }
  const sortedRowInformation = (rowArray, comparator) => {
    // console.log("row information : ", rowArray);
    // console.log("comparator : ", comparator);
    const stabilizedRowArray = rowArray.map((el, index) => [el, index]);
    stabilizedRowArray.sort((a, b) => {
      const order = comparator(a[0], b[0]);
      if (order !== 0) return order;
      return a[1] - b[1];
    });
    return stabilizedRowArray.map((el) => el[0]);
  };
  const handleRequestSort = (event, property) => {
    const isAscending = valueToOrderBy === property && orderDirection === "asc";
    setValueToOrderBy(property);
    setOrderDirection(isAscending ? "desc" : "asc");
  };
  const createSortHandler = (property) => (event) => {
    handleRequestSort(event, property);
  };

  return (
    <div>
      <Header />
      <div className="container py-5 h-100 max-width: 100% ">
        <div className="row d-flex justify-content-center align-items-center h-100">
          <div>
            <div className="card rounded-3">
              <div className="card-body p-4 p-md-5">
                <h3 className="mb-4 pb-2 pb-md-0 mb-md-5 px-md-2">
                  Users Info
                </h3>
                <div
                  style={{
                    display: "flex",
                    flexDirection: "row-reverse",
                    marginBottom: 10,
                  }}
                >
                  <Button onClick={() => navigate("/registerUser")}>
                    <FaPlusCircle size={15} />
                    &nbsp; Add New User
                  </Button>
                  <Form.Control
                    style={{ width: "25%", marginRight: 20 }}
                    className="g-2"
                    placeholder="Search..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>
                <TableContainer>
                  <Table striped bordered hover responsive>
                    <TableHead>
                      <TableRow>
                        <TableCell key="#">
                          <TableSortLabel
                            active={valueToOrderBy === "id"}
                            direction={
                              valueToOrderBy === "id" ? orderDirection : "asc"
                            }
                            onClick={createSortHandler("id")}
                          >
                            #
                          </TableSortLabel>
                        </TableCell>
                        <TableCell key="image">Image</TableCell>
                        <TableCell key="username">
                          <TableSortLabel
                            active={valueToOrderBy === "username"}
                            direction={
                              valueToOrderBy === "username"
                                ? orderDirection
                                : "asc"
                            }
                            onClick={createSortHandler("username")}
                          >
                            Username
                          </TableSortLabel>
                        </TableCell>
                        <TableCell key="email">
                          <TableSortLabel
                            active={valueToOrderBy === "email"}
                            direction={
                              valueToOrderBy === "email"
                                ? orderDirection
                                : "asc"
                            }
                            onClick={createSortHandler("email")}
                          >
                            Email
                          </TableSortLabel>
                        </TableCell>
                        <TableCell key="gender">
                          <TableSortLabel
                            active={valueToOrderBy === "gender"}
                            direction={
                              valueToOrderBy === "gender"
                                ? orderDirection
                                : "asc"
                            }
                            onClick={createSortHandler("gender")}
                          >
                            Gender
                          </TableSortLabel>
                        </TableCell>
                        <TableCell key="dob">
                          <TableSortLabel
                            active={valueToOrderBy === "dob"}
                            direction={
                              valueToOrderBy === "dob" ? orderDirection : "asc"
                            }
                            onClick={createSortHandler("dob")}
                          >
                            Birthdate
                          </TableSortLabel>
                        </TableCell>
                        <TableCell key="city">
                          <TableSortLabel
                            active={valueToOrderBy === "city"}
                            direction={
                              valueToOrderBy === "city" ? orderDirection : "asc"
                            }
                            onClick={createSortHandler("city")}
                          >
                            City
                          </TableSortLabel>
                        </TableCell>
                        <TableCell key="state">
                          <TableSortLabel
                            active={valueToOrderBy === "state"}
                            direction={
                              valueToOrderBy === "state"
                                ? orderDirection
                                : "asc"
                            }
                            onClick={createSortHandler("state")}
                          >
                            State
                          </TableSortLabel>
                        </TableCell>
                        <TableCell key="languages">Languages</TableCell>
                        <TableCell key="action">Actions</TableCell>
                      </TableRow>
                    </TableHead>
                    {userData.users.length === 0 ? (
                      <TableBody
                        style={{ textAlign: "center", verticalAlign: "middle" }}
                      >
                        <TableRow>
                          <td colSpan={10}>No Data found</td>
                        </TableRow>
                      </TableBody>
                    ) : (
                      <tbody
                        style={{ textAlign: "center", verticalAlign: "middle" }}
                      >
                        {userData &&
                          userData.users &&
                          userData.users &&
                          sortedRowInformation(
                            userData.users,
                            getComparator(orderDirection, valueToOrderBy)
                          )
                            .filter((val) => {
                              if (search === "") {
                                return val;
                              } else if (val.username.includes(search)) {
                                return val;
                              }
                            })
                            .slice(
                              page * rowsPerPage,
                              page * rowsPerPage + rowsPerPage
                            )
                            .map((usr, index) => (
                              <tr key={index}>
                                <td>{usr.id}</td>
                                <td>
                                  <div
                                    className="form-outline mb-4 text-center "
                                    style={{ display: "contents" }}
                                  >
                                    <img
                                      src={usr.image}
                                      className=" img-thumbnail rounded-circle z-depth-1-half avatar-pic"
                                      height={150}
                                      width={150}
                                    ></img>
                                  </div>
                                </td>
                                <td className="alignTextBottom">
                                  {usr.username}
                                </td>
                                <td>{usr.email}</td>
                                <td>{usr.gender}</td>
                                <td>{usr.dob}</td>
                                <td>{usr.city}</td>
                                <td>{usr.state}</td>
                                <td>
                                  {usr.language.length == 0
                                    ? ""
                                    : usr.language + ","}
                                </td>

                                <td>
                                  <FaEdit
                                    size={20}
                                    color="#fca903"
                                    onClick={() =>
                                      navigate("updateUser", {
                                        state: { id: usr.id, user: usr },
                                      })
                                    }
                                  />
                                  &nbsp;
                                  <MdDelete
                                    size={20}
                                    color="red"
                                    onClick={() => handleShowDelete(usr.id)}
                                  />
                                  <Modal
                                    show={showDelete}
                                    onHide={handleCloseDelete}
                                    backdrop="static"
                                    keyboard={false}
                                  >
                                    <Modal.Header closeButton>
                                      <Modal.Title>Delete </Modal.Title>
                                    </Modal.Header>
                                    <Modal.Body>
                                      Are you sure want to delete.
                                    </Modal.Body>
                                    <Modal.Footer>
                                      <Button
                                        variant="secondary"
                                        onClick={handleCloseDelete}
                                      >
                                        Close
                                      </Button>
                                      <Button
                                        variant="primary"
                                        onClick={() => handleDelete(deleteId)}
                                      >
                                        Delete
                                      </Button>
                                    </Modal.Footer>
                                  </Modal>
                                </td>
                              </tr>
                            ))}
                      </tbody>
                    )}
                  </Table>
                </TableContainer>

                <TablePagination
                  rowsPerPageOptions={[2, 3, 4, 5]}
                  component="div"
                  count={userData.users.length}
                  rowsPerPage={rowsPerPage}
                  page={page}
                  onPageChange={handleChangePage}
                  onRowsPerPageChange={handleChangesRowsPerPage}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TableTest;
