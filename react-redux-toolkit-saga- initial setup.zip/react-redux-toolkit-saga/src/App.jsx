// import Counter from "./pages/counter";
// import Login from "./pages/login";
import DiamondRing from "./assets/images/diamond-ring.jpg";
import "./App.css";

function App() {
  return (
    <>
      {/* <Counter />
      <div
        style={{
          display: "flex",
          alignItems: "center",
          marginTop: "70px",
          justifyContent: "center",
        }}
      >
        <Login />
      </div> */}

      {/* <div style={{ display: "flex" }}>
        <div style={{ width: "50%" }}>
          <img src={DiamondRing} alt="DiamondRing" />
        </div>
        <div style={{ color: "white" }}>
          <div>
            <div>text</div>
            <input type="text" placeholder="enter email" />
          </div>
        </div>
      </div> */}
    </>
  );
}

export default App;
