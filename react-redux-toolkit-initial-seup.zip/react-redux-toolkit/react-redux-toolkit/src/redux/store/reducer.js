import { combineReducers } from "redux";

// reducer import

import productReducer from "../reducers/product.reducer";

// ==============================|| COMBINE REDUCER ||============================== //

const reducer = combineReducers({
  product: productReducer,
});

export default reducer;
