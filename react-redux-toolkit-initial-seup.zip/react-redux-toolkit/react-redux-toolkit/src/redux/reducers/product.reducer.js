/* eslint-disable no-unused-vars */

import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { GET } from "../../services/methods";

const initialState = {
  products: [],
  isLoading: false,
  error: null,
};

export const getProductThunk = createAsyncThunk(
  "getProduct",
  //--- for passing payload and getting state of redux

  async (payload, { dispatch, getState }) => {
    const res = await GET("/products");
    return res;
  }
);

export const productSlice = createSlice({
  name: "product",
  initialState,

  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(getProductThunk.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(getProductThunk.fulfilled, (state, action) => {
      state.isLoading = false;
      state.products = action.payload;
    });
    builder.addCase(getProductThunk.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.error.message;
    });
  },
});

export const { getProduct } = productSlice.actions;
export default productSlice.reducer;
