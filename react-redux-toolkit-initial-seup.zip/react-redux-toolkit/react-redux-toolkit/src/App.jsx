// import "./App.css";

import Products from "./components/products/Products";

function App() {
  return (
    <>
      <Products />
    </>
  );
}

export default App;
