import { useDispatch, useSelector } from "react-redux";
import { getProductThunk } from "../../redux/reducers/product.reducer";

const Products = () => {
  const dispatch = useDispatch();
  const products = useSelector((state) => state.product.products);
  const isLoading = useSelector((state) => state.product.isLoading);
  const error = useSelector((state) => state.product.error);

  console.log(
    "🚀 ~ file: Products.jsx:8 ~ Products ~ products:",
    products,
    isLoading,
    error
  );
  const handleGetProduct = async () => {
    dispatch(getProductThunk("123"));
  };

  return (
    <div>
      {isLoading && <div>loading</div>}
      {error && <div>Error...</div>}
      <button onClick={() => handleGetProduct()}>Get Products</button>
    </div>
  );
};

export default Products;
