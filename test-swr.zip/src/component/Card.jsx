const url = "https://jsonplaceholder.typicode.com/todos";

const fetcher = () => fetch(url).then((res) => res.json());

const Card = async () => {
  const data = await fetcher();
  return (
    <div>
      {data.map((item) => (
        <div key={item.title}>{item.title}</div>
      ))}
    </div>
  );
};

export default Card;
