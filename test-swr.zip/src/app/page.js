"use client";
import Card from "@/component/Card";
import Image from "next/image";
import { useEffect, useState } from "react";
// import useSWR from "swr";
// const url = "https://jsonplaceholder.typicode.com/todos";

// const fetcher = () => fetch(url).then((res) => res.json());

export default function Home({ initialData }) {
  const [data, setData] = useState([]);
  // const data = await fetcher();
  // console.log(data);

  // const useGetPosts = () => {
  //   const { data, error } = useSWR(url, fetcher);

  //   return { data, error };
  // };

  // const { data: posts, error } = useGetPosts();

  // const { data } = useSWR(URL, fetcher, { initialData });
  // console.log("🚀 ~ file: page.js:21 ~ Home ~ data:", data);

  // useEffect(() => {
  //   fetch(url, {
  //     cache: "force-cache",
  //   })
  //     .then((response) => response.json())
  //     .then((json) => setData(json));
  // }, []);

  return (
    <div>
      <div>static data</div>
      {/* {data.map((item) => (
        <div key={item.title}>{item.title}</div>
      ))} */}
      <Card />
    </div>
  );
}
