import Count from "../../components/count";

const Counter = () => {
  return <Count />;
};

export default Counter;
