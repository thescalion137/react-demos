import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Typography,
} from "@mui/material";
import "./App.css";
import React from "react";
import AddIcon from "@mui/icons-material/Add";
import RemoveIcon from "@mui/icons-material/Remove";

function App() {
  const [expanded, setExpanded] = React.useState(false);

  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };
  return (
    <>
      <div
        style={{
          width: "50%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
        }}
      >
        <Accordion
          expanded={expanded === "panel1"}
          onChange={handleChange("panel1")}
          style={{ color: "white", background: "black",margin:'0px' }}
        >
          <AccordionSummary
            expandIcon={
              expanded === 'panel1' ? (
                <RemoveIcon style={{ color: "white" }} />
              ) : (
                <AddIcon style={{ color: "white" }} />
              )
            }
            aria-controls="panel1bh-content"
            id="panel1bh-header"
          >
            <Typography sx={{ width: "33%", flexShrink: 0 }}>
              General settings
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
           <ul>
            <li style={{listStyle: 'none'}}>Home</li>
            <li style={{listStyle: 'none'}}>About</li>
            <li style={{listStyle: 'none'}}>Process</li>
            <li style={{listStyle: 'none'}}>Contact Us</li>
           </ul>
          </AccordionDetails>
        </Accordion>
        <Accordion
          expanded={expanded === "panel2"}
          onChange={handleChange("panel2")}
          style={{ color: "white", background: "black", margin:'0px' }}
        >
          <AccordionSummary
            expandIcon={
              expanded === "panel2" ? (
                <RemoveIcon style={{ color: "white" }} />
              ) : (
                <AddIcon style={{ color: "white" }} />
              )
            }
            aria-controls="panel2bh-content"
            id="panel2bh-header"
          >
            <Typography sx={{ width: "33%", flexShrink: 0 }}>Users</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Donec placerat, lectus sed mattis semper, neque lectus feugiat
              lectus, varius pulvinar diam eros in elit. Pellentesque convallis
              laoreet laoreet.
            </Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion
          expanded={expanded === "panel3"}
          onChange={handleChange("panel3")}
          style={{ color: "white", background: "black",margin:'0px' }}
        >
          <AccordionSummary
            expandIcon={
              expanded === "panel3" ? (
                <RemoveIcon style={{ color: "white" }} />
              ) : (
                <AddIcon style={{ color: "white" }} />
              )
            }
            aria-controls="panel3bh-content"
            id="panel3bh-header"
          >
            <Typography sx={{ width: "33%", flexShrink: 0 }}>
              Advanced settings
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Nunc vitae orci ultricies, auctor nunc in, volutpat nisl. Integer
              sit amet egestas eros, vitae egestas augue. Duis vel est augue.
            </Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion
          expanded={expanded === "panel4"}
          onChange={handleChange("panel4")}
          style={{ color: "white", background: "black",margin:'0px' }}
        >
          <AccordionSummary
            expandIcon={
              expanded === "panel4" ? (
                <RemoveIcon style={{ color: "white" }} />
              ) : (
                <AddIcon style={{ color: "white" }} />
              )
            }
            aria-controls="panel4bh-content"
            id="panel4bh-header"
          >
            <Typography sx={{ width: "33%", flexShrink: 0 }}>
              Personal data
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Nunc vitae orci ultricies, auctor nunc in, volutpat nisl. Integer
              sit amet egestas eros, vitae egestas augue. Duis vel est augue.
            </Typography>
          </AccordionDetails>
        </Accordion>
      </div>
    </>
  );
}

export default App;
