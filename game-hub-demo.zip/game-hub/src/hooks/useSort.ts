import useData from "./useData";

export interface Platform {
  id: number;
  name: string;
  slug: string;
}

const useSort = () => useData<Platform>("");

export default useSort;
