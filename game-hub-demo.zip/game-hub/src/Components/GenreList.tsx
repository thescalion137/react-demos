import {
  Avatar,
  Box,
  Link,
  List,
  ListItem,
  ListItemAvatar,
} from "@mui/material";
import useGenres, { Genre } from "../hooks/useGenres";
import getCroppedImageUrl from "../services/image-url";
import SidebarSkeleton from "./SidebarSkeleton";

interface GenreListProps {
  onSelectGenre: (genre: Genre) => void;
  selectedGenre: Genre | null;
}

const GenreList = ({ onSelectGenre, selectedGenre }: GenreListProps) => {
  const { data, error, isLoading } = useGenres();
  return (
    <>
      <h2 style={{ paddingLeft: "16px" }}>Genres</h2>
      <List
        sx={{
          height: "100%",
          maxHeight: "calc(100vh - 116px)",
          overflow: "auto",
          "::-webkit-scrollbar": {
            width: "5px",
          },
          "::-webkit-scrollbar-track": {
            background: "transparent",
            borderRadius: "5px",
          },

          "::-webkit-scrollbar-thumb": {
            background: " #d9d9d9",
            borderRadius: "5px",
          },

          "::-webkit-scrollbar-thumb:hover": {
            background: " #7b7b7b",
          },
        }}
      >
        {isLoading &&
          new Array(20)
            .fill(null)
            .map((val, index) => <SidebarSkeleton key={index} />)}
        {data.map((genre, index) => (
          <ListItem
            key={genre.id}
            style={{ paddingTop: "5px", paddingBottom: "5px" }}
          >
            <ListItemAvatar style={{ minWidth: "0px", paddingRight: "10px" }}>
              <Box>
                <img
                  style={{
                    width: " 32px",
                    height: "32px",
                    borderRadius: "8px",
                    objectFit: "cover",
                  }}
                  src={getCroppedImageUrl(genre.image_background)}
                />
              </Box>
            </ListItemAvatar>
            <Link
              component="button"
              color="white"
              underline="hover"
              onClick={() => {
                onSelectGenre(genre);
              }}
              style={{
                fontWeight: genre.id === selectedGenre?.id ? "bold" : "normal",
                textAlign: "left",
              }}
            >
              {genre.name}
            </Link>
          </ListItem>
        ))}
      </List>
    </>
  );
};

export default GenreList;
