import { Icon, Typography } from "@mui/material";
import {
  FaWindows,
  FaPlaystation,
  FaXbox,
  FaApple,
  FaLinux,
  FaAndroid,
} from "react-icons/fa";
import { MdPhoneIphone } from "react-icons/md";
import { SiNintendo } from "react-icons/si";
import { BsGlobe } from "react-icons/bs";
import { IconType } from "react-icons";
import { Platform } from "../hooks/useGames";
import { grey } from "@mui/material/colors";

interface PlatformIconListProps {
  platforms: Platform[];
}
const PlatformIconList = ({ platforms }: PlatformIconListProps) => {
  const iconMap = {
    pc: <FaWindows color="#9e9e9e" style={{ marginRight: "5px" }} key={1} />,
    playstation: (
      <FaPlaystation color="#9e9e9e" style={{ marginRight: "5px" }} key={2} />
    ),
    xbox: <FaXbox color="#9e9e9e" style={{ marginRight: "5px" }} key={3} />,
    nintendo: (
      <SiNintendo color="#9e9e9e" style={{ marginRight: "5px" }} key={4} />
    ),
    mac: <FaApple color="#9e9e9e" style={{ marginRight: "5px" }} key={5} />,
    linux: <FaLinux color="#9e9e9e" style={{ marginRight: "5px" }} key={6} />,
    android: (
      <FaAndroid color="#9e9e9e" style={{ marginRight: "5px" }} key={7} />
    ),
    ios: (
      <MdPhoneIphone color="#9e9e9e" style={{ marginRight: "5px" }} key={8} />
    ),
    web: <BsGlobe key={9} />,
  };

  // const iconMap: { [key: string]: IconType } = {
  //   pc: FaWindows,
  //   playstation: FaPlaystation,
  //   xbox: FaXbox,
  //   nintendo: SiNintendo,
  //   mac: FaApple,
  //   linux: FaLinux,
  //   android: FaAndroid,
  //   ios: MdPhoneIphone,
  //   web: BsGlobe
  // }
  return (
    <div style={{ display: "flex", margin: "4px" }}>
      {platforms.map(
        (platform: any) =>
          // @ts-ignore type error
          iconMap[platform.slug]
      )}
    </div>
  );
};

export default PlatformIconList;
