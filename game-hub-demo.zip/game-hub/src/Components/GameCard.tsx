import React from "react";
import { Game } from "../hooks/useGames";
import { Card, CardContent, CardMedia, Typography } from "@mui/material";
import PlatformIconList from "./PlatformIconList";
import CriticScore from "./CriticScore";
import getCroppedImageUrl from "../services/image-url";
import Emoji from "./Emoji";

interface GameCardProps {
  game: Game;
}

const GameCard = ({ game }: GameCardProps) => {
  return (
    <Card sx={{ borderRadius: "10px", height: "100%" }}>
      <CardMedia
        component="img"
        image={getCroppedImageUrl(game.background_image)}
        alt={game.name}
      />
      <CardContent>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            paddingBottom: "5px",
          }}
        >
          <PlatformIconList
            platforms={game.parent_platforms.map((p) => p.platform)}
          />
          {/* <CriticScore score={game.metacritic} /> */}
        </div>
        <Typography
          gutterBottom
          variant="h5"
          component="div"
          sx={{ fontWeight: "bold" }}
        >
          {game.name}
          <Emoji rating={game.rating_top} />
        </Typography>
      </CardContent>
    </Card>
  );
};

export default GameCard;
