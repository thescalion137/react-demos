import { Box } from "@mui/material";
import React from "react";

const GameCardContainer = () => {
  return <Box> </Box>;
};

export default GameCardContainer;
