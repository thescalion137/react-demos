import {
  Box,
  Card,
  CardContent,
  ListItem,
  ListItemAvatar,
  Skeleton,
} from "@mui/material";
import React from "react";

const SidebarSkeleton = () => {
  return (
    <ListItem style={{ paddingTop: "5px", paddingBottom: "5px" }}>
      <ListItemAvatar style={{ minWidth: "0px", paddingRight: "10px" }}>
        <Skeleton
          variant="rectangular"
          style={{ borderRadius: "8px", width: " 32px", height: "32px" }}
        />
      </ListItemAvatar>
      <Box>
        <Skeleton width="80px" />
      </Box>
    </ListItem>
  );
};

export default SidebarSkeleton;
