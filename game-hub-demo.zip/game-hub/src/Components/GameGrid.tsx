import { Grid } from "@mui/material";
import useGames, { Platform } from "../hooks/useGames";
import GameCard from "./GameCard";
import GameCardSkeleton from "./GameCardSkeleton";
import { Genre } from "../hooks/useGenres";
import { GameQuery } from "../App";

export interface GameGridProps {
  gameQuery: GameQuery;
}

const GameGrid = ({ gameQuery }: GameGridProps) => {
  const { data, error, isLoading } = useGames(gameQuery);

  if (error) {
    {
      <div>{error}</div>;
    }
  }
  return (
    <>
      <Grid
        container
        columns={{ xs: 4, sm: 8, md: 12, lg: 12, xl: 12 }}
        spacing={{ xs: 2, md: 3, lg: 3 }}
        padding="10px"
      >
        {isLoading &&
          new Array(12).fill(null).map((val, index) => (
            <Grid
              item
              xs={4}
              sm={4}
              md={4}
              lg={4}
              xl={3}
              style={{ borderRadius: "20px" }}
              key={index}
            >
              <GameCardSkeleton />
            </Grid>
          ))}
        {data.map((game) => (
          <Grid
            item
            xs={4}
            sm={4}
            md={4}
            lg={4}
            xl={3}
            key={game.id}
            style={{
              borderRadius: "20px",
            }}
          >
            <GameCard game={game} />
          </Grid>
        ))}
      </Grid>
    </>
  );
};

export default GameGrid;
