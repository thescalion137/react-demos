import { Card, CardContent, Skeleton } from "@mui/material";
import React from "react";

const GameCardSkeleton = () => {
  return (
    <Card sx={{ borderRadius: "10px", height: "100%" }}>
      <Skeleton variant="rectangular" width="100%" height={200} />
      <CardContent>
        <Skeleton />
        <Skeleton width="60%" />
      </CardContent>
    </Card>
  );
};

export default GameCardSkeleton;
