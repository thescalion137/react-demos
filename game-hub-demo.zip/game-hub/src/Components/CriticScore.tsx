import { Badge } from "@mui/material";
import React from "react";

interface CriticScoreProps {
  score: number;
}

const CriticScore = ({ score }: CriticScoreProps) => {
  let color = score > 75 ? "#22543d" : score > 60 ? "#744210" : "";
  let background = score > 75 ? "#c6f6d5" : score > 60 ? "#fefcbf" : "";
  return (
    <span
      style={{
        whiteSpace: "nowrap",
        textTransform: "uppercase",
        borderRadius: "0.125rem",
        fontWeight: "700",
        background: background,
        color: color,
        fontSize: "0.7em",
        display: "flex",
        alignItems: "center",
        padding: "0px 7px",
      }}
    >
      {score}
    </span>
  );
};

export default CriticScore;
