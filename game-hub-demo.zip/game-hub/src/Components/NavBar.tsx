import React from "react";
import logo from "../assets/logo.webp";
import ColorModeSwitch from "./ColorModeSwitch";
import { Button } from "@mui/material";
import SearchInput from "./SearchInput";

interface SearchInputProps {
  onSearch: (searchText: string) => void;
}

const Navbar = ({ onSearch }: SearchInputProps) => {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        padding: "10px",
        alignItems: "center",
      }}
    >
      <img src={logo} height="60px" width="60px" />
      <SearchInput onSearch={onSearch} />
      <ColorModeSwitch />
    </div>
  );
};

export default Navbar;
