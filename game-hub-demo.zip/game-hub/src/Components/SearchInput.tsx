import { InputAdornment, OutlinedInput } from "@mui/material";
import React, { useRef, useState } from "react";
import { BsSearch } from "react-icons/bs";

interface SearchInputProps {
  onSearch: (searchText: string) => void;
}

const SearchInput = ({ onSearch }: SearchInputProps) => {
  const [searchText, setSearchText] = useState<string>("");

  const hndleSubmit = () => {
    if (searchText) {
      onSearch(searchText);
    }
  };
  return (
    <form
      onSubmit={(event) => {
        event.preventDefault();
        hndleSubmit();
      }}
      style={{ width: "100%" }}
    >
      <OutlinedInput
        startAdornment={
          <InputAdornment position="start">
            <BsSearch />
          </InputAdornment>
        }
        sx={{
          "& .MuiOutlinedInput-input": {
            padding: "10px",
          },
          width: "100%",
          borderRadius: "20px",
        }}
        placeholder="Search games..."
        value={searchText}
        onChange={(e) => setSearchText(e.target.value)}
      />
    </form>
  );
};

export default SearchInput;
