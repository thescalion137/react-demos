import axios from "axios";

export default axios.create({
  baseURL: "https://api.rawg.io/api",
  params: {
    key: "2010d8ba2c674d749059763733c5f5af",
  },
});
