import mainTheme from "./mainTheme";

const themes = {
  mainTheme,
};

export default themes;
