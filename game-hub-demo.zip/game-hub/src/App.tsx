import { Box, Grid } from "@mui/material";
import { useState } from "react";
import GameGrid from "./Components/GameGrid";
import Navbar from "./Components/NavBar";
import GenreList from "./Components/GenreList";
import { Genre } from "./hooks/useGenres";
import PlatformSelector from "./Components/PlatformSelector";
import { Platform } from "./hooks/usePlatforms";
import SortSelector from "./Components/SortSelector";
import GameHeading from "./Components/GameHeading";

export interface GameQuery {
  genre: Genre | null;
  platform: Platform | null;
  sortOrder: string;
  searchText: string | null;
}
function App() {
  const [gameQuery, setGameQuery] = useState<GameQuery>({} as GameQuery);

  return (
    <Grid container>
      <Grid item sm={12} xs={12} md={12} lg={12} xl={12}>
        <Navbar
          onSearch={(searchText) => setGameQuery({ ...gameQuery, searchText })}
        />
      </Grid>
      <Grid
        item
        md={2}
        xl={1.5}
        sx={{
          display: {
            xs: "none",
            sm: "none",
            md: "block",
            lg: "block",
            xl: "block",
          },
        }}
      >
        <GenreList
          selectedGenre={gameQuery.genre}
          onSelectGenre={(genre) => setGameQuery({ ...gameQuery, genre })}
        />
      </Grid>
      <Grid item xs={12} sm={12} lg={10} md={10} xl={10.5}>
        <Box sx={{ paddingLeft: "8px" }}>
          <GameHeading gameQuery={gameQuery} />
          <Box
            sx={{
              display: "flex",
              gap: "20px",
            }}
          >
            <PlatformSelector
              selectedPlatform={gameQuery.platform}
              setSelectedPlatform={(platform) =>
                setGameQuery({ ...gameQuery, platform })
              }
            />
            <SortSelector
              sortOrder={gameQuery.sortOrder}
              onSelectSortOrder={(sortOrder) =>
                setGameQuery({ ...gameQuery, sortOrder })
              }
            />
          </Box>
        </Box>
        <Box
          sx={{
            height: "100%",
            maxHeight: "calc(100vh - 173px)",
            overflow: "auto",
            marginTop: "5px",
            "::-webkit-scrollbar": {
              width: "5px",
            },
            "::-webkit-scrollbar-track": {
              background: "transparent",
              borderRadius: "5px",
            },

            "::-webkit-scrollbar-thumb": {
              background: " #d9d9d9",
              borderRadius: "5px",
            },

            "::-webkit-scrollbar-thumb:hover": {
              background: " #7b7b7b",
            },
          }}
        >
          <GameGrid gameQuery={gameQuery} />
        </Box>
      </Grid>
    </Grid>
  );
}

export default App;
