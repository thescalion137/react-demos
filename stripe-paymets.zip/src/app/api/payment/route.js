import Stripe from "stripe";
import { NextResponse } from "next/server";

export async function POST(request) {
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
  let data = await request.json();
  let priceId = data.priceId;
  let couponId = data.couponId;

  const session = await stripe.checkout.sessions.create({
    line_items: [
      {
        price: priceId,
        quantity: 1,
      },
    ],
    mode: "payment",
    discounts: [
      {
        coupon: couponId,
      },
    ],
    allow_promotion_codes: true,
    // payment_method_types: ["card"],

    success_url: "http://localhost:3000/pricing",
    cancel_url: "http://localhost:3000/pricing",
  });
  return NextResponse.json(session.url);
}
